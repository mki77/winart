### About:
These are free artwork, you can redistribute them and/or modify them under the terms of the [GPL](<http://www.gnu.org/licenses/>) license.

### How to convert to linux cursor:
	sudo apt install python3-pip breeze-cursor-theme
	pip install win2xcur
	./make
